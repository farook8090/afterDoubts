// !Price change when clicked on the radio button.

// ?function name is changeprice(price)

function changeprice(price) {
  // Shown in this ID.
  document.getElementById("result").innerHTML = "₹" + price;

  // ?..Worked Smoothly
    // alert('Worked..Bruh but price not changing.');
}
