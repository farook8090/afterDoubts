// !This function is used to get small alphabet printed on the place on big alphabet.

// ! function name is given on the element which we want to make appear when clicked on over.

// & onclick

function changealphabet(small_alphabet) {
  // This function will make the small alphabet get print on big alphabet.
  document.getElementById("big-alphabet").innerHTML = small_alphabet;
  // alert('error');
}
